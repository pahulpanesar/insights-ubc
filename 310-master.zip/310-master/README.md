# 310
Insight UBC is a site which allows querying of course and building information from UBC's metadata. Build with typescript and with html, css for UI. 
